"""
Author : GOVIND
Date   : 01-06-2024
"""


# class ParentClass:
#     parent_class_variable = "parent class variable"
#
#     def __init__(self, parent_instance_variable):
#         self.parent_instance_variable = parent_instance_variable
#         self._protected_variable_parent = "parent protected variable"
#         self.__private_variable_parent = "parent private variable"
#
#     def instance_method_parent(self):
#         print("parent instance method")
#
#     def get_protected_variable_parent(self):
#         return self._protected_variable_parent
#
#     def _protected_method_parent(self):
#         print("parent protected method")
#
#     def __private_method_parent(self):
#         print("parent private method")
#
#     @classmethod
#     def class_method_example_parent(cls):
#         print("parent class method using @classmethod")
#
#     @staticmethod
#     def static_method_example_parent():
#         print("parent static method using @staticmethod")
#
#
# class ChildClass(ParentClass):
#     def __init__(self, child_instance_variable):
#         super().__init__(child_instance_variable)  # Initialize parent class with instance variable
#         self.child_instance_variable = child_instance_variable  # Define child's instance variable
#
#     def call_super_methods(self):
#         print(self.parent_instance_variable)  # Access parent's instance variable using self (inherited)
#         print(super().parent_class_variable)  # Accessing class variable
#         print(super().get_protected_variable_parent())  # Accessing protected variable
#
#         # Can't access private variable directly outside the class
#         # print(super().__private_variable)
#
#         super().class_method_example_parent()  # Calling class method
#         super().instance_method_parent()  # Calling instance method
#         super()._protected_method_parent()  # Calling protected method
#
#         # Can't access private method directly outside the class
#         # super().__private_method()
#
#     @classmethod
#     def class_method_example(cls):
#         print("ChildClass method using @classmethod")
#
#     @staticmethod
#     def static_method_example():
#         print("ChildClass static method using @staticmethod")
#
#
# # Creating an instance of ChildClass class
# cc_obj = ChildClass("ChildClass Instance variable")
# cc_obj.call_super_methods()
#
# # Accessing class methods and static methods
# ChildClass.class_method_example()
# ChildClass.static_method_example()

"***********************************************************************"

class School:
    def __init__(self, school_name):
        self.school_name = school_name
        self._prot_var = "pro var"
        self.__private_var = "private var"

    def get_school_name(self):
        return f"School name is {self.school_name}"


class Admin:

    def get_school_name(self):
        return "School name is {Admin}"
class Sports:
    def get_school_name(self):
        return "School name is {Sports}"
class Student(School, Admin, Sports):
    def __init__(self, stu_name, age):
        super().__init__("Amazon")
        self.stu_name = stu_name
        self.age = age

    def get_student_data(self):
        # self.school_name = "Amazon"
        return f"name: {self.stu_name}, age: {self.age}, school:{self.school_name}"
        # return f"{self._prot_var}"
        # return School("sch").get_school_name()
        # return super().get_school_name()
    def get_school_name(self):
        return "School name is {Sports}"

stu_obj = Student("John", 30)
print(stu_obj.get_student_data())

